package dao;

import java.util.List;

import beans.CustomerBean;
//import beans.VendorBean;

public interface CustomerDAO {
	
	public String registerVendor(CustomerBean vendor);
	
	public List<CustomerBean> getAllVendors();
	
	public boolean validatePassword(String vendorId,String password);
	
	public String updateProfile(CustomerBean vendor);
	
	public String changePassword(String vendorId,String oldPassword,String newPassword);
	
	public CustomerBean getVendorDataById(String vendorId);
}
