package dao;


import java.util.List;

import beans.ProductBean;
import beans.ProductStatusBean;
//import beans.TenderBean;
//import beans.TenderStatusBean;

public interface ProductDAO {
	
	public List<ProductBean> getTenderDetails(String id);
	
	public List<ProductBean> getAllTenders();
	
	public String createTender(ProductBean product);
	
	public boolean removeTender(String tid);
	
	public String updateTender(ProductBean product);
	
	public ProductBean getTenderDataById(String tenderId);
	
	public String getTenderStatus(String tenderId);
	
	public String assignTender(String tenderId,String vendorId,String bidderId);
	
	public List<ProductStatusBean> getAllAssignedTenders();
	
}
